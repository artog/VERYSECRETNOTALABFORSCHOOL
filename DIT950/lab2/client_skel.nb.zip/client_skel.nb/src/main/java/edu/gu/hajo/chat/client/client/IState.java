package edu.gu.hajo.chat.client.client;



/**
 * The contract for the different states using
 * the State pattern
 * @author hajo
 *
 */
public interface IState {
  
}
