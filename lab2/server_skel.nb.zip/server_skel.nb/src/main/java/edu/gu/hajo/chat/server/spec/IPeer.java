package edu.gu.hajo.chat.server.spec;

import java.rmi.Remote;

/**
 * One clients view of another (peer2peer)
 *
 * @author hajo
 *
 */
public interface IPeer extends Remote {

}
