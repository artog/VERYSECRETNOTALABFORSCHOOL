/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.gu.hajo.chat.server.core;

/**
 * Application global constants
 * @author hajo
 */
public class Constants {
    public static final String CLIENT_PING_MESSAGE = "Client alive";
    public static final String SERVER_PING_MESSAGE = "Server alive";
    public static final String SERVER_NAME = "ServerName";
    public static final String NONE = "none";
}
