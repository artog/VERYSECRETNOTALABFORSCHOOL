package TSim;

public class UnparsableInputException extends Exception
{            
    public UnparsableInputException(String s) 
    {
	super(s);
    }
}
